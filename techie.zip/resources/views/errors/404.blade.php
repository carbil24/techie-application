<h2>
    Page does not exist.<br/>
    <a href="/">Go to home</a>
</h2>