@if(session('status'))
    <h2 class="bg-light text-center text-black-50 py-3 shadow">{{ session('status') }}</h2>
@endif