<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/app.css">
    <script src="/js/app.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0-1/css/all.css" rel="stylesheet">

</head>
<body>
    <div id="app" class="d-flex flex-column h-screen 
                         justify-content-between">
        <header>
        <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.session-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    </header>

    <main class="py-4">    
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-white text-center text-black-50 py-2 shadow">
        <a href="<?php echo e(route('home')); ?>"><h4 class="text-primary navbar-brand"><?php echo e(config('app.name')); ?> | Copyright @ <?php echo e(date('yy')); ?></h2></a>
        <div class="justify-content-between align-items-center">
            <a href="https://www.facebook.com/"><i class="social facebook fab fa-facebook fa-2x"></i></a>
            <a href="https://www.instagram.com/"><i class="social instagram fab fa-instagram fa-2x"></i></a>
            <a href="https://www.twitter.com/"><i class="social twitter fab fa-twitter fa-2x"></i></a>
        </div>
    </footer>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Project\resources\views/layout.blade.php ENDPATH**/ ?>