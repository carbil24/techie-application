<?php $__env->startSection('title', 'Contact'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-10 col-lg-6 mx-auto">
            <form class="bg-white shadow rounded py-3 px-4"
                method="POST" 
                action="<?php echo e(route('contacts.store')); ?>"
            >
                <?php echo csrf_field(); ?>
                <h1 class="display-4">Contact</h1>
                <hr>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input class="form-control bg-light shadow-sm
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php else: ?>
                                    border-0
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="name" 
                        name="name"
                        placeholder="Please enter your name..." 
                        value="<?php if(auth()->guard()->check()): ?><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>"
                    >
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!--<?php echo $errors->first('name', '<small>:message</small><br/>'); ?> -->
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control bg-light shadow-sm
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php else: ?>
                                    border-0
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="email" 
                        name="email"
                        placeholder="Please enter your email address..." 
                        value="<?php if(auth()->guard()->check()): ?><?php echo e(auth()->user()->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>"
                    >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input class="form-control bg-light shadow-sm
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php else: ?>
                                    border-0
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="subject" 
                        name="subject"
                        placeholder="Please enter the subject of your message..." 
                        value="<?php echo e(old('subject')); ?>"
                    >
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea class="form-control bg-light shadow-sm
                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                <?php else: ?>
                                    border-0
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="content" 
                        name="content"
                        placeholder="Please enter the content of your message..."><?php echo e(old('content')); ?>

                    </textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group d-none">
                    <input class="form-control bg-light shadow-sm" 
                        id="isUser" 
                        name="isUser"
                        value="<?php if(auth()->guard()->guest()): ?><?php echo e('no'); ?><?php else: ?><?php echo e('yes'); ?><?php endif; ?>"
                    >
                </div>
                <button class="btn btn-primary btn-lg btn-block">Send</button>
                <a class="btn btn-link btn-block" href="<?php echo e(route('home')); ?>">Cancel</a>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/contact.blade.php ENDPATH**/ ?>