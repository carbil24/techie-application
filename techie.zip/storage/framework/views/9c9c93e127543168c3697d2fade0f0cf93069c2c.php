<?php if(session('status')): ?>
    <h2 class="bg-light text-center text-black-50 py-3 shadow"><?php echo e(session('status')); ?></h2>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/partials/session-status.blade.php ENDPATH**/ ?>