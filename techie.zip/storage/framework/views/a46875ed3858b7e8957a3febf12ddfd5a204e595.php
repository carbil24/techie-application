<?php $__env->startSection('title', 'Create Project'); ?>


<?php $__env->startSection('content'); ?>

    <h1>Edit Project</h1>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('projects.update', $project)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <label>
            Project Title<br>
            <input type="text" name="title" value="<?php echo e(old('title', $project->title)); ?>">
        </label>
        <br>
        <label>
            Project Description<br>
            <textarea name="description"><?php echo e(old('description', $project->description)); ?></textarea>
        </label>
        <button>Update</button>
        
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/projects/edit.blade.php ENDPATH**/ ?>