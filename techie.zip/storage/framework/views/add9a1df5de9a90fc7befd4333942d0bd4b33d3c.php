<?php $__env->startSection('title', 'Message of '. $contact->name); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-10 mx-auto">
        <h2 class="bg-light text-center text-black-50 py-3 shadow">Please enter an answer for this request.</h2>

            <div class="bg-white p-5 shadow rounded">
                <h2 class="display-5 mb-1"><?php echo e($contact->name); ?></h2>
                <h3 class="display-5 mb-1"><?php echo e($contact->email); ?></h3>
                <?php if($contact->created_at->diffInHours() > 24): ?>
                <p class="bg-danger text-light"><?php echo e('Requested on ' . $contact->created_at->subHours(5)->format('d/m/Y') . ' at ' . $contact->created_at->subHours(5) ->format('h:i a')); ?></p>
                <?php else: ?>
                <p><?php echo e('Requested on ' . $contact->created_at->subHours(5)->format('d/m/Y') . ' at ' . $contact->created_at->subHours(5) ->format('h:i a')); ?></p>
                <?php endif; ?>
                <p></p><span>Subject: </span><span class="text-black-50"><?php echo e($contact->subject); ?></span></p>
                <span>Content: </span><span class="text-black-50"><?php echo e($contact->content); ?></span>
                    <form class="py-4"
                        method="POST" 
                        action="<?php echo e(route('contacts.update', $contact)); ?>"
                    >
                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                        <div class="form-group">
                            <label for="answer">Answer:</label>
                            <textarea class="form-control bg-light shadow-sm
                                        <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            is-invalid
                                        <?php else: ?>
                                            border-0
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="answer" 
                                name="answer"
                                placeholder="Please enter the answer for the request..."><?php echo e(old('answer')); ?>

                            </textarea>
                            <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>        
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group d-none">
                            <input class="form-control bg-light shadow-sm" 
                            id="replied" 
                            name="replied"
                            value="yes"
                            >
                        </div>  
                        <div class="d-flex justify-content-between align-items-center"> 
                 
                        <div class="btn-group btn-gr">
                            <a class="btn btn-primary" href="<?php echo e(route('contacts.index')); ?>">Cancel</a>
                            <button class="btn btn-primary">Reply</button>
                        </div>
                    </div>
                </form>    
            </div>
        </div>
    </div> 
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/contacts/confirmDeleteContact.blade.php ENDPATH**/ ?>