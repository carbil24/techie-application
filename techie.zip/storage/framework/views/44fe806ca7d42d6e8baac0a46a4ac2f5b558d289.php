<?php $__env->startSection('title', 'Jobs'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-10 mx-auto">

            <div class="bg-white p-5 shadow rounded">

                <h1 class="text-primary display-4 mb-0">Jobs</h1>
                <hr>

                <div class="col-12 col-sm-10 col-lg-6 mx-auto">

                    <form method="GET" action="<?php echo e(route('jobs.search')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                        <label for="location" class="col-md-2 col-form-label"><?php echo e(__('Location')); ?></label>

                        <div class="col-md-10">
                            <input id="location" type="text" class="form-control" name="location" value="<?php echo e(old('location')); ?>" autocomplete="location" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="keyword" class="col-md-2 col-form-label"><?php echo e(__('Keyword')); ?></label>

                            <div class="col-md-10">
                                <input id="keyword" type="text" class="form-control" name="keywords" value="<?php echo e(old('keyword')); ?>" autocomplete="keyword" autofocus>
                            </div>
                        </div>

                        <button class="btn btn-secondary btn-md btn-block mb-5">Search</button>

                    </form>
                </div>

                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item border-0 mb-3 shadow-sm">
                        <h2><a class="text-secondary d-flex justify-content-between align-items-center" href="<?php echo e(route('jobs.show', $job)); ?>"><?php echo e($job->title); ?> - <?php echo e($job->company); ?></a></h2>
                        <h4><?php echo e($job->company); ?></h4>
                        <p><?php echo e($job->location); ?></p>
                        <p><?php echo e($job->created_at->format('d/m/Y')); ?></p>
                    
                        <div class="d-flex justify-content-end align-items-center">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->email=='admin@techie.com'): ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('jobs.edit', $job)); ?>">Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(route('jobs.confirmDelete', $job)); ?>">Delete</a>

                                <!-- <form class="d-none" id="delete-job" method='POST' action="<?php echo e(route('jobs.destroy', $job)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                </form> -->
                                <?php else: ?>

                                    <?php if($job->users()->where('id', Auth::user()->id) ->exists()): ?>
                                        <a class="btn btn-primary mr-2 star-liked" href="<?php echo e(route('like_job', $job)); ?>">★</a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-primary mr-2 star" href="<?php echo e(route('like_job', $job)); ?>">★</a>
                                    <?php endif; ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('applyToJob', $job)); ?>">Apply</a>

                                <?php endif; ?>
                            <?php else: ?>
                                    <a class="btn btn-outline-primary mr-2 star" href="<?php echo e(route('login')); ?>" onclick="alert('You need to be logged in to like a job');" class="star">★</a>
                                    <a class="btn btn-outline-primary" href="<?php echo e(route('login')); ?>" onclick="alert('You need to be logged in to apply');">Apply</a>
                            <?php endif; ?>
                        </div>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item border-0 mb-3 shadow-sm">There is no jobs to show</li>
                    <?php endif; ?>
                    </li>
                    <?php echo e($jobs->links()); ?>

                </ul>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/jobs/index.blade.php ENDPATH**/ ?>