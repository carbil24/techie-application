<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-6 mx-auto">
            <div class="bg-white p-5 shadow rounded">
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->email=='admin@techie.com'): ?>
                <h1 class="col-12 text-primary text-center display-5 mb-3"><?php echo e('Please select an option: '); ?> </h1>
                <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('jobs.index')); ?>">Job Management</a>
                <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('jobs.create')); ?>">Add a new job</a>
                <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('contacts.index')); ?>">Contact Management</a>


                <?php else: ?>
                    <h1 class="col-12 text-primary text-center display-5 mb-0"><?php echo e('Hey ' . auth()->user()->first_name . ' find the tech job right for you!'); ?> </h1>
                    <hr>
                    <form method="GET" action="<?php echo e(route('jobs.search')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                        <label for="location" class="col-md-2 col-form-label"><?php echo e(__('Location')); ?></label>
                        <div class="col-md-10">
                            <input id="location" type="text" class="form-control" name="location" value="<?php echo e(old('location')); ?>" autocomplete="location" autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="keyword" class="col-md-2 col-form-label"><?php echo e(__('Keyword')); ?></label>

                            <div class="col-md-10">
                                <input id="keyword" type="text" class="form-control" name="keywords" value="<?php echo e(old('keyword')); ?>" autocomplete="keyword" autofocus>
                            </div>
                        </div>
                        <button class="btn btn-secondary btn-md btn-block mb-5">Search</button>
                    </form>

                    <div class="d-flex justify-content-center align-items-center">
                        <img src="<?php echo e(URL::asset('/images/undraw_online_cv_qy9w.png')); ?>" width="50%" alt="image"/>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <h1 class="col-12 text-primary text-center display-5 mb-0"><?php echo e('Welcome to TECHIE. Find the tech job right for you!'); ?> </h1>
                <hr>
                <form method="GET" action="<?php echo e(route('jobs.search')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                    <label for="location" class="col-md-2 col-form-label"><?php echo e(__('Location')); ?></label>
                    <div class="col-md-10">
                        <input id="location" type="text" class="form-control" name="location" value="<?php echo e(old('location')); ?>" autocomplete="location" autofocus>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="keyword" class="col-md-2 col-form-label"><?php echo e(__('Keyword')); ?></label>

                        <div class="col-md-10">
                            <input id="keyword" type="text" class="form-control" name="keywords" value="<?php echo e(old('keyword')); ?>" autocomplete="keyword" autofocus>
                        </div>
                    </div>
                    <button class="btn btn-secondary btn-md btn-block mb-5">Search</button>
                </form>   
                <div class="d-flex justify-content-center align-items-center">
                    <a class="btn btn-primary btn-lg btn-block mb-2" href="<?php echo e(route('login')); ?>">Login</a>
                </div>
                <div class="d-flex justify-content-center align-items-center">
                    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('register')); ?>">Register</a>
                </div> 
                <div class="d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(URL::asset('/images/undraw_online_cv_qy9w.png')); ?>" width="50%" alt="image"/>
                </div>

            <?php endif; ?>

            </div>
        </div>             
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/home.blade.php ENDPATH**/ ?>