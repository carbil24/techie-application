<?php $__env->startSection('title', 'Jobs | ' . $job->title); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-10 mx-auto">

            <div class="bg-white p-5 shadow rounded">
                <div class="d-flex justify-content-between align-items-center">
                    <h1 class="text-primary display-4 mb-1"><?php echo e($job->title); ?></h1>
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="btn btn-outline-primary mr-2 star" href="<?php echo e(route('login')); ?>" onclick="alert('You need to be logged in to like a job');" class="star">★</a>
                    <?php else: ?>                    
                        <?php if(Auth::user()->email<>'admin@techie.com'): ?>
                            <?php if($job->users()->where('id', Auth::user()->id) ->exists()): ?>
                                <a class="btn btn-primary mr-2 star-liked" href="<?php echo e(route('like_job', $job)); ?>">★</a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary mr-2 star" href="<?php echo e(route('like_job', $job)); ?>">★</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <h3 class="display-5 mb-1"><?php echo e($job->company); ?> - <?php echo e($job->location); ?></h3>
                <p class="text-secondary"><?php echo e($job->description); ?></p>
                <p class="text-black-50"><?php echo e($job->created_at -> diffForHumans()); ?></p>                 
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->email=='admin@techie.com'): ?>
                        <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('jobs.edit', $job)); ?>">Edit</a>
                        <a class="btn btn-danger btn-lg btn-block" href="#" onclick="document.getElementById('delete-job').submit();">Delete</a>
                        <a class="btn btn-link btn-block" href="<?php echo e(route('jobs.index')); ?>">Cancel</a>                  
                    <?php else: ?>
                        <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('applyToJob', $job)); ?>">Apply</a>
                        <a class="btn btn-link btn-block btn-lg btn-block" href="<?php echo e(route('jobs.index')); ?>">Back</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="btn btn-outline-primary btn-lg btn-block" href="<?php echo e(route('login')); ?>" onclick="alert('You need to be logged in to apply');">Apply</a>
                    <a class="btn btn-link btn-block btn-lg btn-block" href="<?php echo e(route('jobs.index')); ?>">Back</a>
                <?php endif; ?>  
            </div>
            <form class="d-none" id="delete-job" method='POST' action="<?php echo e(route('jobs.destroy', $job)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            </form>
        </div>
    </div> 
</div> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/jobs/show.blade.php ENDPATH**/ ?>