<?php $__env->startSection('title', 'Liked Jobs'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-10 mx-auto">

            <div class="bg-white p-5 shadow rounded">

                <h1 class="text-primary display-4 mb-0">Liked Jobs</h1>
                <hr>
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $user->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item border-0 mb-3 shadow-sm">
                        <h2><a class="text-secondary d-flex justify-content-between align-items-center" href="<?php echo e(route('jobs.show', $job)); ?>"><?php echo e($job->title); ?> - <?php echo e($job->company); ?></a></h2>
                        <p><?php echo e($job->company); ?></p>
                        <p><?php echo e($job->location); ?></p>
                        <p><?php echo e($job->created_at->format('d/m/Y')); ?></p>
                        <div class="d-flex justify-content-end align-items-center">

                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->email=='admin@techie.com'): ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('jobs.edit', $job)); ?>">Edit</a>
                                <?php else: ?>

                                    <?php if($job->users()->where('id', Auth::user()->id) ->exists()): ?>
                                        <a class="btn btn-primary mr-2" href="<?php echo e(route('like_job', $job)); ?>" class="star star-liked">★</a>
                                    <?php else: ?>
                                        <a class="btn btn-primary mr-2" href="<?php echo e(route('like_job', $job)); ?>" class="star">★</a>
                                    <?php endif; ?>
                                    <a class="btn btn-primary" href="<?php echo e(route('applyToJob', $job)); ?>">Apply</a>

                                <?php endif; ?>
                            <?php else: ?>
                                    <a class="btn btn-primary mr-2" href="<?php echo e(route('login')); ?>" class="star">★</a>
                                    <a class="btn btn-primary" href="#" onclick="alert('You need to be logged in to apply');">Apply</a>
                            <?php endif; ?>
                        </div>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item border-0 mb-3 shadow-sm">There is no jobs to show</li>
                    <?php endif; ?>
                    </li>
                </ul>
                <a class="btn btn-link btn-block" href="<?php echo e(route('jobs.index')); ?>">Back</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/likedjobs.blade.php ENDPATH**/ ?>