<?php $__env->startSection('title', 'Profile | ' . auth()->user()->email); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-12 col-sm-10 col-lg-10 mx-auto">

            <div class="bg-white p-5 shadow rounded">
            
                <h1 class="text-primary display-4 mb-0">Personal Info</h1>
                <hr>
                <h4 class="display-5 mb-1">Name: <?php if(Auth::user()->email=='admin@techie.com'): ?>
                                                <?php echo e(auth()->user()->first_name); ?>

                                           <?php else: ?>
                                                <?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?>

                                           <?php endif; ?>  </h4>
                <p class="display-5 mb-1">Email: <?php echo e(auth()->user()->email); ?></p>
                <p class="display-5 mb-1">Phone: <?php echo e(auth()->user()->phone); ?><p>

                    <form action="<?php echo e(route('profile.uploadCV')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                            <label for="answer">Description:</label>
                            <textarea class="form-control bg-light shadow-sm
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            is-invalid
                                        <?php else: ?>
                                            border-0
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="description" 
                                name="description"
                                placeholder="Please enter a description of you..."><?php echo e(old('description', auth()->user()->description)); ?>

                            </textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>        
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php if(auth()->user()->completed =='yes'): ?>
                    <div class="form-group embed-responsive embed-responsive-1by1">
                        <label>Your already uploaded your CV.</label>
                        <embed src="<?php echo e(URL::asset(auth()->user()->curriculum)); ?>" class="embed-responsive-item"/>
                      </div>
                    <div class="form-group">
                        <label>Upload a new CV:</label>
                        <input type="file" class="form-control-file" name="curriculum" id="curriculum" aria-describedby="fileHelp">
                        <small id="fileHelp" class="form-text text-muted">Please upload a valid file. Size of file should not be more than 2MB.</small>
                      </div>
                    <?php else: ?>
                    <div class="form-group">
                    <label>Please upload your CV:</label>
                        <input type="file" class="form-control-file" name="curriculum" id="curriculum" aria-describedby="fileHelp" required>
                        <small id="fileHelp" class="form-text text-muted">Please upload a valid file. Size of file should not be more than 2MB.</small>
                      </div>
                    <?php endif; ?>  
                    <div class="form-group d-none">
                            <input class="form-control bg-light shadow-sm" 
                            id="completed" 
                            name="completed"
                            value="yes"
                            >
                        </div>   
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                    <a class="btn btn-link btn-block" href="<?php echo e(route('home')); ?>">Cancel</a>
                    </form>
                
            </div>
        </div>
    </div> 
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/profile.blade.php ENDPATH**/ ?>