<h2>
    Page does not exist.<br/>
    <a href="/">Go to home</a>
</h2><?php /**PATH C:\xampp\htdocs\Project\resources\views/errors/404.blade.php ENDPATH**/ ?>