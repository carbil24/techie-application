<nav class="navbar navbar-light navbar-expand-lg bg-white shadow-sm">
    <div class="container">
        <a class="text-primary display-2 navbar-brand" href="<?php echo e(route('home')); ?>">
            <?php echo e(config('app.name')); ?>

        </a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link <?php echo e(setActive('home')); ?>" href="<?php echo e(route('home')); ?>">Home</a></li>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('/jobs.*')); ?>" href="<?php echo e(route('jobs.index')); ?>">Jobs</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('contacts.create')); ?>" href="<?php echo e(route('contacts.create')); ?>">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('login')); ?>" href="<?php echo e(route('login')); ?>">Login</a></li>

                <?php else: ?>
                    <?php if(Auth::user()->email=='admin@techie.com'): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('/jobs.*')); ?>" href="<?php echo e(route('jobs.index')); ?>">Job Management</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('jobs.create')); ?>" href="<?php echo e(route('jobs.create')); ?>">Add a job</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(setActive('contacts.index')); ?>" href="<?php echo e(route('contacts.index')); ?>">Contact Management</a></li>


                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link <?php echo e(setActive('/jobs.*')); ?>" href="<?php echo e(route('jobs.index')); ?>">Jobs</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(setActive('likedjobs')); ?>" href="<?php echo e(route('likedjobs')); ?>">Liked Jobs</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(setActive('contacts.create')); ?>" href="<?php echo e(route('contacts.create')); ?>">Contact Us</a></li>

                    <?php endif; ?>
                <li class="nav-item"><a class="nav-link" href="#" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"
                    >Logout</a>
                </li>   
                 
                <?php endif; ?>

            </ul>
        </div>
        <?php if(auth()->guard()->check()): ?>
        <span class="nav nav-pills">
        <?php if(Auth::user()->email=='admin@techie.com'): ?>
            <span class="text-primary" >Admin</span>                   
        <?php else: ?>
            <?php if(Auth::user()->completed =='yes'): ?>
                <a class="nav-link <?php echo e(setActive('profile')); ?> " href="<?php echo e(route('profile')); ?>"><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></a>
            <?php else: ?>
                <a class="nav-link <?php echo e(setActive('profile')); ?> " href="<?php echo e(route('profile')); ?>"><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></a>
                <a href="<?php echo e(route('profile')); ?>" ><i class="fa fa-exclamation-circle fa-2x text-danger" aria-hidden="true" title="Please complete your profile"></a></i>
            <?php endif; ?>    
        <?php endif; ?>
            </span>
        <?php endif; ?>

        <button class="navbar-toggler" type="button" 
                data-toggle="collapse" 
                data-target="#navbarSupportedContent" 
                aria-controls="navbarSupportedContent" 
                aria-expanded="false" 
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form><?php /**PATH C:\xampp\htdocs\Project\resources\views/partials/nav.blade.php ENDPATH**/ ?>